export class Telefone {
    telefoneId?: number;
    numero?: string;
    tipoTelefone?: string;
}