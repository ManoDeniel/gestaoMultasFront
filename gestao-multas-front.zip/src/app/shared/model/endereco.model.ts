export class Endereco {
    enderecoId?: number;
    rua?: string;
    numero?: string;
    tipoLogradouro?: string;
    bairro?: string;
    cidade?: string;
    estado?: string;
    cep?: string;
}