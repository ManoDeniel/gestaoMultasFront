export class Pageable {
    content: any[];
    sort: number;
    size: number;
    totalElements: number;
    totalPages: number;
    first: number;
    last: number;
    pageable: any[];
}