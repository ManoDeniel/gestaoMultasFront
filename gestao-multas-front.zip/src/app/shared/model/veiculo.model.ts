export class Veiculo {
    veiculoId: number;
    marca: string;
    modelo: string;
    anoFabricacao: string;
    cor: string;
    placa: string;
    numeroRenavam: string;
    motoristaId?: number;
}