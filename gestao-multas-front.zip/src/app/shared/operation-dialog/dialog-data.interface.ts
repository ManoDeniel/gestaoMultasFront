export interface DialogData {
    operation: string;
    message: string;
}